/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmpe331_project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author simge
 */
public class MyFunctions {
    
    public static String studentName(int id) throws SQLException{
        Connection con = My_Connection.getConnection();
        Statement st;
        st = con.createStatement();
        String student_name = "";
        ResultSet rs = st.executeQuery("SELECT * FROM `student`");
        while(rs.next()){
         if(id == rs.getInt(1)){
         student_name = rs.getString(2);
    }}
        return student_name;
    }
    
}
